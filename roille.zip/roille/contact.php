<?php
      
// Sélection et affichage du template PHTML.
$template = 'contact';
include 'layout.phtml';
       
  
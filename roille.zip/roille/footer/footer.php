<section>
           <h3 class="titrePiedPage">Location De Matériel De Chantier</h3>
           <p>Contactez Notre Équipe De Location</p>
           <div>
               <h3>A propos de Roille</h3>
               <ul>
                   <li>mail : contact@roille.com</li>
                   <li>tel : 09876666788</li>
                   <li>facebook</li>
               </ul>
           </div><!--

            --><div>
               <h3>Informations Légales</h3>
               <ul>
                   <li>Nos CGU</li>
                   <li>Montions Légales</li>
               </ul>
           </div><!--

            --><div>
               <h3>Offre de location</h3>
               <ul>
                   <li>Location mini pelle</li>
                   <li>Location nacelle elevatrice</li>
                   <li>Location chariot élevateur</li>
                   <li>Location tractopelle</li>
                   <li>Location benne</li>
               </ul>
           </div>
  </section>
  <section class="copyright">
        <p>Copyright [ 2021 ] - Roille</p>
</section>
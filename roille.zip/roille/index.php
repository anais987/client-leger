
<?php
session_start();

   
       
  // Sélection et affichage du template PHTML.
$template = 'index';
include 'layout.phtml';



drop database if exists roille;
create database roille;
use roille;



DROP TABLE IF EXISTS client;
CREATE TABLE IF NOT EXISTS client(
    id_client int auto_increment,
    nom varchar(50) NOT NULL,
    mdp varchar(50) NOT NULL,
    addresse varchar(250) NOT NULL,
    codeP char(10) NOT NULL,
    ville varchar(40) NOT NULL,
    pays varchar(20) DEFAULT NULL,
    phone char(10) NOT NULL,
    mail varchar(50) NOT NULL,
    constraint pk_customer PRIMARY KEY (id_client)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS particulier;
 CREATE TABLE IF NOT EXISTS particulier (
id_client int auto_increment,
nom varchar(50) not null,
prenom varchar(50) not null,
mdp varchar(50) not null,
addresse varchar(250) not null,
codeP char(10) not null,
ville varchar(40) not null,
pays varchar(20) not null,
phone char(10) not null,
mail varchar(50) not null,
PRIMARY KEY (id_client)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS professionnel;
 CREATE TABLE IF NOT EXISTS professionnel (
id_client int(11) not null auto_increment,
nom varchar(50) not null,
mdp varchar(50) not null,
addresse varchar(250) not null,
codeP char(10) not null,
ville varchar(40) not null,
pays varchar(20) not null,
phone char(10) not null,
mail varchar(50) not null,
numSiret int(70) not null,
statut_juridique varchar(50) not null,
PRIMARY KEY (id_client)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS commande;
CREATE TABLE IF NOT EXISTS commande(
    id_comm int(11) NOT NULL auto_increment,
    total_comm float(10) NOT NULL,
    date_comm date not null,
    date_commliv date not null,
    etat_comm set('valider','en attente','annuler'),
    id_client int(11) NOT NULL,
    constraint pk_order PRIMARY KEY (id_comm),
    foreign key (id_client) references client (id_client)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS categorie;
CREATE TABLE IF NOT EXISTS categories(
    id_categorie int(11) NOT NULL auto_increment,
    nom varchar(50) NOT NULL,
    constraint pk_categories primary key (id_categorie)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS produit;
CREATE TABLE IF NOT EXISTS produit(
    id_produit int(11) NOT NULL auto_increment,
    nomp varchar(50) NOT NULL,
    descp varchar (250) NOT NULL,
    prixHTp float(5) NOT NULL,
    prixTTCp float(5) NOT NULL,
    tva float(50) not null,
    id_categorie integer not null,
    constraint pk_productt primary key (id_produit),
    foreign key (id_categorie) references categories (id_categorie)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS order_detail;
CREATE TABLE IF NOT EXISTS order_detail(
    quantite_com int(50) NOT NULL,
    id_com integer not null,
    id_produit integer not null,
    constraint pk_detailsOrder primary key (id_com,id_produit),
    foreign key (id_com) references commande (id_comm), 
    foreign key (id_produit) references produit (id_produit)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists bon_commande;
create table if not exists delivery_note(
    id_bonComm int(11) not null auto_increment,
    id_com integer not null,
    constraint pk_deliveryNote primary key (id_bonComm),
    foreign key (id_com) references commande (id_comm)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists detail_livraison;
create table if not exists detail_livraison(
    id_bonCom int(20) not null,
    id_produit int(20) not null,
    quantityLiv int(20) not null,
    constraint pk_detailsDelivery PRIMARY KEY (id_bonCom,id_produit),
    foreign key (id_bonCom) references bon_commande (id_bonComm),
    foreign key (id_produit) references produit (id_produit)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*
 trigger pour l'ajout d'un professionnel
*/
drop trigger if exists ajout_professionnel ;
 delimiter //
 create trigger ajout_professionnel 
 before insert on professionnel 
 for each row  
 begin 
declare x,e int ;
select max(id_client) into x 
from particulier;
if x =0
  then 
      set  x= 1;
      else
       set new.id_client= x+1;  
end if;
     insert into client values (new.id_client,new.nom,new.mdp,new.addresse,new.codeP,new.ville,new.pays
                          ,new.phone,new.mail);
end //
delimiter ;



/*
 trigger pour l'ajout d'un particulier
*/
drop trigger if exists ajout_particulier ;
 delimiter //
 create trigger ajout_particulier 
 before insert on particulier 
 for each row  
 begin 
declare a,x,e int ;
select max(id_client) into x 
from professionnel;
if x =0
  then 
      set  x= 1;
      else
       set new.id_client= x+1;  
end if;
     insert into client values (new.id_client,new.nom,new.mdp,new.addresse,new.codeP,new.ville,new.pays
                          ,new.phone,new.mail);
end //
delimiter ;


insert into client values(null,'sonia','sonia','paris','98700','paris','france',098778483,'sonia@sonia.com');
insert into particulier values(null,'soso','soso','soso','paris','98700','paris','france',098778483,
'sonia@sonia.com');


insert into professionnel values(null,'soso','soso','paris','98700','paris','france',098778483,
'sonia@sonia.com',3445553322,'disid');
select * from professionnel;
select * from particulier;
select * from client;


/*
 trigger pour la mise à jour de la table client une fois que la table particulier est modifiée
*/
drop trigger if exists updatParticulier;
delimiter //
create trigger updatParticulier
after update on particulier
for each row
begin
    update client
set 
    id_client=new.id_client,
    nom=new.nom,
    mdp=new.mdp,
    addresse=new.addresse,
    codeP=new.codeP,
    ville=new.ville,
    pays=new.pays,
    phone=new.phone,
    mail=new.mail
    where id_client=old.id_client;
end //
delimiter ;

/*
 trigger pour la mise à jour de la table client une fois que la table professionnel est modifiée
*/
drop trigger if exists updatProfessionnel;
delimiter //
create trigger updatProfessionnel
after update on professionnel
for each row
begin
    update client
set 
    id_client=new.id_client,
    nom=new.nom,
    mdp=new.mdp,
    addresse=new.addresse,
    codeP=new.codeP,
    ville=new.ville,
    pays=new.pays,
    phone=new.phone,
    mail=new.mail
    where id_client=old.id_client;
end //
delimiter ;

update particulier set 
    nom='sosooo',
    prenom='sosooo',
    mdp='soso',
    addresse='soso',
    codeP='98700',
    ville='paris',
    pays='france',
    phone=098778483,
    mail='sonia@sonia.com'
where id_client=2;

update professionnel set 
    nom='sosooo',
    mdp='soso',
    addresse='soso',
    codeP='98700',
    ville='paris',
    pays='france',
    phone=098778483,
    mail='sonia@sonia.com',
    numSiret=3445553322,
    statut_juridique='disid'
where id_client=1;

/* trigger qui permet de supprimer un particulier dans la table client*/
drop trigger if exists deleteParticulier;
delimiter //
create trigger deleteParticulier
after delete on particulier
for each row
begin
    delete from client where id_client=old.id_client;
end //
delimiter ;


/* trigger qui permet de supprimer un professionnel dans la table client*/
drop trigger if exists delProfessionnel;
delimiter //
create trigger delProfessionnel
after delete on professionnel
for each row
begin
    delete from client where id_client=old.id_client;
end //
delimiter ;

 delete from particulier where id_client =1;




























delimiter //
create trigger prixTtcProcudct
before insert on product
for each row
begin
set new.tva=new.buyPrice_HT * 0.2;
set new.salePrice_TTC=new.buyPrice_HT + new.tva;
end //
delimiter ;


delimiter //
create trigger  prixTaxeRate
before insert on order_details
for each row
begin
set new.taxe_amount=new.taxe_rat* 0.2;
end //
delimiter;

create table archiComm as
select * , sysdate() date_histo from `order`
where 2=0;
alter table archiComm
add primary key (id_order);


drop trigger if exists histocom;
delimiter //
create trigger histocom
after insert on order_details
for each row
begin
delete from `order` where order_status='valider';
end //
delimiter ;

insert into archiComm select *,curdate()
from `order` where order_status='valider';

create view vArchiComm (numcomm,total,date,deliveryDate,status,num_client,dateArchi)
as select * ,curdate() from `order`
where order_status="valider";

drop event `Something To Doo`;
SHOW VARIABLES LIKE 'event_schedulerr';
SET GLOBAL event_scheduler = 1;
CREATE EVENT `Something To Doo`
ON SCHEDULE AT CURRENT_TIMESTAMP + INTERVAL 30 second
do delete from `order` where order_status='valider';


insert into `order` values(null,1000,curdate(),curdate()+3,'en attente',9);
insert into `order` values(null,1000,curdate(),curdate()+3,'valider',3);
insert into `customer` values(null,'sonia','sonia','paris','98700','paris','france',098778483,'sonia@sonia.com');
insert into `customer` values(null,'soso','soso','paris','98700','paris','france',098778483,'soso@soso.com');
update `order` set order_status="valider" where id_order=18;
insert into order_details values(null,10,20,32,9,1);

INSERT INTO `order_details` (`order_quantity`, `taxe_rat`, `taxe_amount`, `id_order`, `id_product`) 
VALUES (10, 20, 32, 23,1);


/*
delimiter //
drop trigger if exists deleteOrdderAttente;
create trigger deleteOrdderAttente
before delete on `order`
for each row
begin
if old.order_status != 'valider' or old.order_status != 'annuler'
then
    signal sqlstate '45000'
    set message_text='cette commande est en attente';
end if;
end //
delimiter ;

*/

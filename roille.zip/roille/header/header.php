<nav>
        <ul>
                            
                                <li><a href="index.php">accueil</a></li>
                                <li><a href="categories.php">Categories</a></li>
                                <li><a href="#">Guides</a></li>
                                <li><a href="#">Location d'engeins</a></li>
                                <li><a href="contact.php">Nous contactez</a></li>
                                <li>
                                    <?php
                                        if(isset( $_SESSION['lastName']))
                                        {
                                                echo "<h1>Bonjour : ". $_SESSION['lastName']."</h1>";
                                                echo "<a href='deConnect.php'>déconnexion</a>";
                                        }
                                        else{

                                           echo "<li><a href='inscription.php'>Mon compte</a></li>";
                                        }
                                    ?>
                                </li>
                                <li><a href="#">Rencherche</a></li>
            
        </ul>
    </nav>
        
        
        
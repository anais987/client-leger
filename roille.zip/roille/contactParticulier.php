<?php
require('application/database.php');
if(isset($_POST['envoyer']))
{
    if(!empty($_POST) && isset($_POST)){

        $nom=htmlspecialchars($_POST['nom']);
        $prenom=htmlspecialchars($_POST['prenom']);
        $mdp=htmlspecialchars($_POST['mdp']);
        $addresse=htmlspecialchars($_POST['addresse']);
        $codeP=htmlspecialchars($_POST['codeP']);
        $ville=htmlspecialchars($_POST['ville']);
        $pays=htmlspecialchars($_POST['pays']);
        $phone=htmlspecialchars($_POST['phone']);
        $mail=htmlspecialchars($_POST['mail']);
print_r($_POST);
    
        registerParticulier($nom,$prenom,$mdp,$addresse,$codeP,$ville,$pays,$phone,$mail);                                         
    }
}

// Sélection et affichage du template PHTML.
$template = 'contactParticulier';
include 'layout.phtml';
?>
<?php 

session_start();
    if(isset($_POST['ok']))
    {
        $login=$_POST["lastName"];
        $mdp=$_POST["mdp"];
        $id= mysqli_connect("127.0.0.1","root","","roille");
        $connect= mysqli_query($id,"SET NAMES 'utf8'");
        $req="select * from customer where lastName='$login' and mdp='$mdp'";
        $result=mysqli_query($id,$req);
        if(mysqli_num_rows($result)>0)
        {
            $ligne=mysqli_fetch_assoc($result);
            $_SESSION['id_client']=$ligne['id_client'];
            $_SESSION['lastName']=$ligne['lastName'];
            $_SESSION['address']=$ligne['address'];
            $_SESSION['city']=$ligne['city'];
            $_SESSION['country']=$ligne['country'];
            $_SESSION['phone']=$ligne['phone'];
            $_SESSION['mail']=$ligne['mail'];
            $_SESSION['country']=$ligne['country'];
            header('location:index.php?id='. $_SESSION["id_client"]);
        }
        else{
            $erreur= "connexion impossible, login ou mot de passe incorrect ....";
        }
    }

   
    // Sélection et affichage du template PHTML.
$template = 'connexion';
include 'layout.phtml';


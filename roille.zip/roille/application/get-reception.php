<ol class="faux">
    <li>réception du matériel suite à un état des lieux et à la signature du contrat de location</li>
    <li>le service Wootmat reste en support pendant toute la durée de la location</li>
    <li>retour du matériel précédé d'un état des lieux de retour</li>

</ol>
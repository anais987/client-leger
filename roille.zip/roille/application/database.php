<?php

function createconnectionn(){
    $pdo=new PDO('mysql:host=localhost;dbname=roille;charset=utf8','root','');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
}
function registerParticulier($nom,$prenom,$mdp,$addresse,$codeP,$ville,$pays,$phone,$mail){
    $pdo=createconnectionn();
    $req=$pdo->prepare("INSERT INTO particulier (nom,prenom,mdp,addresse,codeP,ville,pays,phone,mail)
                        values (:nom,:prenom,:mdp,:addresse,:codeP,:ville,:pays,:phone,:mail)");
    $req->execute(array(
        ':nom'=>$nom,
        ':prenom'=>$prenom,
        ':mdp'=>$mdp,
        ':addresse'=>$addresse,
        ':codeP'=>$codeP,
        ':ville'=>$ville,
        ':pays'=>$pays,
        ':phone'=>$phone,
        ':mail'=>$mail
    ));                      
}

function registerProfessionnel($nom,$mdp,$addresse,$codeP,$ville,$pays,$phone,$mail,$numSiret,$statut_juridique){
    $pdo=createconnectionn();
    $req=$pdo->prepare("INSERT INTO professionnel 
                        (nom,mdp,addresse,codeP,ville,pays,phone,mail,numSiret,statut_juridique)
                        values (:nom,:mdp,:addresse,:codeP,:ville,:pays,:phone,:mail,:numSire,:statut_jurid)");
    $req->execute(array(
        ':nom'=>$nom,
        ':mdp'=>$mdp,
        ':addresse'=>$addresse,
        ':codeP'=>$codeP,
        ':ville'=>$ville,
        ':pays'=>$pays,
        ':phone'=>$phone,
        ':mail'=>$mail,
        ':numSire'=>$numSiret,
        ':statut_jurid'=>$statut_juridique
    ));                      
}


?>
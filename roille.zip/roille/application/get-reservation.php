<ol class="faux">
    <li>demande en ligne et reception par email de votre devis de location en moins de 30 minutes</li>
    <li>le service Wootmat me contacte pour la mise en place de la location en moins de 2 heures</li>
    <li>paiement par carte bancaire à la confirmation de la location de l'équipement de chantier</li>

</ol>
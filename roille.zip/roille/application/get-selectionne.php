<ol class="faux">
    <li>recherche de votre location de matériel de chantier grâce aux filtres de catégories</li>
    <li>sélection de l’offre correspondante à votre location et à votre besoin</li>
    <li>saisie des détails de mon besoin (dates et durée de location, choix livraison et opérateur)</li>

</ol>
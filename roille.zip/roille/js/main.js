
// Afficher comment sélectionner une location de matériel de chantier en ligne
// en utilisant AJAX 


$(function () {
    $('#selectionne').on('click', classifiedBuy);
    $('#selectionne').on('click', color1);

});
function classifiedBuy() {
    $.get('application/get-selectionne.php', function (response) {
        $('#serviceDetails').html(response);
    });
}

function color1() {
        $('#selectionne').css('color','#f9bb2d');
        $('#reservation').css('color','#666');
        $('#reception').css('color','#666');
}




// Afficher comment réserver ma location de matériel
// en utilisant AJAX 

$(function () {
    $('#reservation').on('click', classifiedReservation);
    $('#reservation').on('click', color2);
});
function classifiedReservation() {
    $.get('application/get-reservation.php', function (response) {
        $('#serviceDetails').html(response);
    });
}
function color2() {
    $('#reservation').css('color','#f9bb2d');
    $('#selectionne').css('color','#666');
    $('#reception').css('color','#666');
}




// Afficher comment réceptionner mon matériel ou équipement
// en utilisant AJAX

$(function () {
    $('#reception').on('click', classifiedReception);
    $('#reception').on('click', color3);
});
function classifiedReception() {
    $.get('application/get-reception.php', function (response) {
        $('#serviceDetails').html(response);
    });
}

function color3() {
    $('#reception').css('color','#f9bb2d');
    $('#reservation').css('color','#666');
    $('#selectionne').css('color','#666');
}
/*
function maFonctionUn(){
    document.querySelector('#btnAfficheInfosServiceUn').innerHTML='<i class="fas fa-chevron-up"></i>';
    $('.afficheInfosServiceUn').show(3000);
}

function maFonctionDeux(){
    document.querySelector('#btnAfficheInfosServiceDeux').innerHTML='<i class="fas fa-chevron-up"></i>';
    $('.afficheInfosServiceDeux').show(3000);
}

function maFonctionTrois(){
    document.querySelector('#btnAfficheInfosServiceTrois').innerHTML='<i class="fas fa-chevron-up"></i>';
    $('.afficheInfosServiceTrois').show(3000);
}

function maFonctionQuatre(){
    document.querySelector('#btnAfficheInfosServiceQuatre').innerHTML='<i class="fas fa-chevron-up"></i>';
    $('.afficheInfosServiceQuatre').show(3000);
}

function maFonctionCinq(){
    document.querySelector('#btnAfficheInfosServiceCinq').innerHTML='<i class="fas fa-chevron-up"></i>';
    $('.afficheInfosServiceCinq').show(3000);
}

function maFonctionSix(){
    
    document.querySelector('#btnAfficheInfosServiceSix').innerHTML='<i id="btn2" class="fas fa-chevron-up"></i>';

    $('.afficheInfosServiceSix').show(3000);
}
function montre(){

    $('.afficheInfosServiceSix').css("display","none");
    
}
let btn=document.getElementById('btn2');
alert(btn);
document.querySelector('#btnAfficheInfosServiceUn').addEventListener("click",maFonctionUn);
document.querySelector('#btnAfficheInfosServiceDeux').addEventListener("click",maFonctionDeux);
document.querySelector('#btnAfficheInfosServiceTrois').addEventListener("click",maFonctionTrois);
document.querySelector('#btnAfficheInfosServiceQuatre').addEventListener("click",maFonctionQuatre);
document.querySelector('#btnAfficheInfosServiceCinq').addEventListener("click",maFonctionCinq);
document.querySelector('#btnAfficheInfosServiceSix').addEventListener("click",maFonctionSix);
   
    
btn.addEventListener("click",montre);
*/
/*$(function () {
    
    $('#btnAfficheInfosService').on('click', montre);
    $('#btnAfficheInfosService').on('click', cacher);
});

function cacher(){
    $('#afficheInfosService').css("display","none");
}
function montre(){
    $('#afficheInfosService').fadeIn(1000);
    
}


*/


